export const ACTIONS = Object.freeze({
  OFFSCREEN_PLAY: 'OFFSCREEN_PLAY',
  OFFSCREEN_SET_VOLUME: 'OFFSCREEN_SET_VOLUME',
  OFFSCREEN_STATE_CHANGED: 'OFFSCREEN_STATE_CHANGED',
  POPUP_GET_DATA: 'POPUP_GET_DATA',
  POPUP_PLAY_STREAM: 'POPUP_PLAY_STREAM',
  OPTIONS_GET_DATA: 'OPTIONS_GET_DATA',
  OPTIONS_SET_CUSTOM_STATION: 'OPTIONS_SET_CUSTOM_STATION',
  OPTIONS_SET_VOLUME: 'OPTIONS_SET_VOLUME',
  OPTIONS_RESET_ITEMS: 'OPTIONS_RESET_ITEMS',
  OPTIONS_PLAY_STREAM: 'OPTIONS_PLAY_STREAM'
});

export const AUDIO_STATES = Object.freeze({
  STOPPED: 'stopped',
  LOADING: 'loading',
  PLAYING: 'playing',
  PAUSED: 'paused',
  ERROR: 'error'
});

// API base URL (prod): https://miniradio.ca
// API base URL (dev): http://localhost:8787
// API paths:
// - PROXY_PATH: /proxy
// - TRACK_PATH: /api/track
// - VALIDATE_PATH: /validate
export const API_ENDPOINTS = Object.freeze({
  BASE_URL: 'https://miniradio.ca',
  PROXY_PATH: '/proxy',
  TRACK_PATH: '/api/track',
  VALIDATE_PATH: '/validate'
});

export const VALIDATE_STATES = Object.freeze({
  PENDING: 'pending',
  VALIDATING: 'validating',
  VALID: 'valid',
  FALLBACK: 'fallback',
  INVALID: 'invalid'
});
