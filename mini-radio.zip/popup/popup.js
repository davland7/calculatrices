import { ACTIONS, AUDIO_STATES } from "../constants/constant.js";
import { sendMessage } from "../utils/extension.js";
import { getLangCode, t } from "../utils/i18n.js";

const elements = {
  stations: document.getElementById("stations"),
  template: document.querySelector("template"),
  pagination: document.querySelector("nav ul"),
  options: document.getElementById("optionsPage"),
  get playerControls() {
    return document.querySelectorAll(".station__control");
  }
};

const playerStateConfig = {
  [AUDIO_STATES.LOADING]: {
    className: "station__control--loading",
    titleKey: "popup_tooltip_loading"
  },
  [AUDIO_STATES.PLAYING]: {
    className: "station__control--pause",
    titleKey: "popup_tooltip_pause"
  },
  [AUDIO_STATES.PAUSED]: {
    className: "station__control--play",
    titleKey: "popup_tooltip_play"
  },
  [AUDIO_STATES.ERROR]: {
    className: "station__control--play",
    titleKey: "popup_tooltip_play"
  }
};

const ITEMS_PER_PAGE = 4;
let currentState = AUDIO_STATES.STOPPED;
let currentPage = 1;

function lockControls() {
  elements.playerControls.forEach((btn) =>
    btn.classList.add("station__control--locked")
  );
}

function unlockControls() {
  elements.playerControls.forEach((btn) =>
    btn.classList.remove("station__control--locked")
  );
}

async function playStation(event, station) {
  if (currentState === AUDIO_STATES.LOADING) return;

  const clicked = event.currentTarget.closest(".station");
  const isPlayer = elements.stations.firstElementChild === clicked;

  lockControls();

  if (isPlayer) {
    if (
      currentState === AUDIO_STATES.STOPPED ||
      currentState === AUDIO_STATES.ERROR
    ) {
      await sendMessage(ACTIONS.POPUP_PLAY_STREAM, { station });
    } else {
      await sendMessage(ACTIONS.OFFSCREEN_PLAY);
    }
    return;
  }

  elements.stations.prepend(clicked);
  displayPage(currentPage);
  await sendMessage(ACTIONS.POPUP_PLAY_STREAM, { station });
}

function displayPage(page) {
  currentPage = page;

  elements.pagination.querySelectorAll("button").forEach((btn) => {
    const isActive = Number(btn.dataset.page) === page;
    btn.classList.toggle("active", isActive);
    if (isActive) {
      btn.setAttribute("aria-current", "page");
    } else {
      btn.removeAttribute("aria-current");
    }
  });

  const items = Array.from(elements.stations.children).slice(1);
  const start = (page - 1) * ITEMS_PER_PAGE;
  const end = start + ITEMS_PER_PAGE;

  items.forEach((item, i) => {
    item.style.display = i >= start && i < end ? "grid" : "none";
  });
}

function renderStation(station) {
  const { image, name, description } = station;
  const clone = elements.template.content.cloneNode(true);

  clone.querySelector(".station__image").src = image;
  clone.querySelector(".station__name").textContent = name;
  clone.querySelector(".station__description").textContent = description;

  const btn = clone.querySelector(".station__control");
  btn.addEventListener("click", (event) => playStation(event, station));
  const playLabel = t(playerStateConfig[AUDIO_STATES.PAUSED].titleKey);
  btn.title = playLabel;
  btn.ariaLabel = `${playLabel} – ${name}`;

  return clone;
}

function addCustomStationButton() {
  const li = document.createElement("li");
  li.classList.add("station--custom");

  const btn = document.createElement("button");
  btn.textContent = t("popup_add_custom_station");
  btn.addEventListener("click", () => chrome.runtime.openOptionsPage());

  li.appendChild(btn);
  elements.stations.appendChild(li);
}

function updatePlayerButtonState(newState) {
  currentState = newState;

  const config =
    playerStateConfig[newState] || playerStateConfig[AUDIO_STATES.PAUSED];
  const paused = playerStateConfig[AUDIO_STATES.PAUSED];
  const allClasses = Object.values(playerStateConfig).map((c) => c.className);

  elements.playerControls.forEach((btn, index) => {
    btn.classList.remove(...allClasses);

    const target = index === 0 ? config : paused;
    btn.classList.add(target.className);
    const label = t(target.titleKey);
    btn.title = label;
    const stationName = btn
      .closest(".station")
      ?.querySelector(".station__name")?.textContent;
    btn.ariaLabel = stationName ? `${label} – ${stationName}` : label;
  });
}

chrome.runtime.onMessage.addListener((message) => {
  if (message.action === ACTIONS.OFFSCREEN_STATE_CHANGED) {
    updatePlayerButtonState(message.state);
    if (message.state === AUDIO_STATES.LOADING) {
      lockControls();
    } else {
      unlockControls();
    }
  }

  return false;
});

(async () => {
  try {
    const { state, stations } = await sendMessage(ACTIONS.POPUP_GET_DATA);

    stations.forEach((station) => {
      elements.stations.appendChild(renderStation(station));
    });

    updatePlayerButtonState(state);

    if (stations.length < 13) addCustomStationButton();

    document.documentElement.lang = getLangCode();
    elements.options.textContent = t("popup_options_page");
    elements.options.addEventListener("click", (event) => {
      event.preventDefault();
      chrome.runtime.openOptionsPage();
    });

    elements.pagination.addEventListener("click", (event) => {
      if (event.target.tagName === "BUTTON") {
        displayPage(Number(event.target.dataset.page));
      }
    });

    displayPage(1);
  } catch (error) {
    console.error("[Popup] Init failed:", error);
  }
})();
