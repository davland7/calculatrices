/**
 * Sends a message to the runtime and returns a promise
 * @param {string} action - Action to send
 * @param {object} params - Additional parameters
 * @returns {Promise<any>}
 */
export function sendMessage(action, params = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ action, ...params }, (response) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(response);
      }
    });
  });
}

/**
 * Wrapper to handle errors in listeners
 * @param {Function} fn - Handler function
 * @returns {Function} - Handler with error handling
 */
export function withErrorHandling(fn) {
  return (params) => {
    const action = params?.request?.action || 'unknown';
    const { sendResponse } = params || {};

    const sendReply = (data) => {
      if (typeof sendResponse === 'function') {
        try { sendResponse(data); } catch (_error) {}
      }
    };

    Promise.resolve(fn(params))
      .then(response => sendReply(response || { success: true }))
      .catch(error => {
        console.error(`[ServiceWorker] Action ${action} failed: ${error?.message || error}`);
        sendReply({ success: false, error: error?.message || 'Unknown error' });
      });

    return true;
  };
}

/**
 * Gets the extension version
 * @returns {string}
 */
export function getVersion() {
  return chrome.runtime.getManifest().version;
}
