import { REQUIRED_ORIGINS } from '../constants/constant.js';

let coreGranted = false;

function toOriginPattern(url) {
  try { return `${new URL(url).origin}/*`; } catch { return null; }
}

export async function ensurePermissions(stationSrc) {
  const origins = [...REQUIRED_ORIGINS];

  if (stationSrc) {
    const pattern = toOriginPattern(stationSrc);
    if (pattern && !origins.includes(pattern)) origins.push(pattern);
  }

  const isCore = origins.length === REQUIRED_ORIGINS.length;

  if (coreGranted && isCore) return true;

  const has = await chrome.permissions.contains({ origins });

  if (has) {
    if (isCore) coreGranted = true;
    return true;
  }

  const result = await chrome.permissions.request({ origins });

  if (result && isCore) coreGranted = true;

  return result;
}
