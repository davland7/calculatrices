import { REQUIRED_ORIGINS } from "../constants/constant.js";

let coreGranted = false;

/**
 * Resets the cached state for core permissions.
 */
export function resetCoreGranted() {
  coreGranted = false;
}

/**
 * Converts a URL to a Chrome origin pattern.
 * @param {string} rawUrl
 * @returns {string | null}
 */
function toOriginPattern(rawUrl) {
  try {
    const url = new URL(rawUrl);
    return `${url.origin}/*`;
  } catch {
    return null;
  }
}

/**
 * Ensures required origins are granted, including an optional custom station origin.
 * If the custom station origin is already granted, Chrome will not prompt again.
 * @param {string} stationSrc
 * @returns {Promise<boolean>}
 */
export async function ensurePermissions(stationSrc) {
  const origins = [...REQUIRED_ORIGINS];

  if (stationSrc) {
    const pattern = toOriginPattern(stationSrc);
    if (pattern && !origins.includes(pattern)) origins.push(pattern);
  }

  const isCore = origins.length === REQUIRED_ORIGINS.length;

  if (coreGranted && isCore) return true;

  const has = await chrome.permissions.contains({ origins });

  if (has) {
    if (isCore) coreGranted = true;
    return true;
  }

  const result = await chrome.permissions.request({ origins });

  if (result && isCore) coreGranted = true;

  return result;
}

/**
 * Removes the permission associated with a custom station source URL.
 * @param {string} customStationSrc
 * @returns {Promise<boolean>}
 */
export async function removeCustomPermission(customStationSrc) {
  const pattern = toOriginPattern(customStationSrc);
  if (pattern) {
    // Wait for Chrome's response before confirming removal.
    return await chrome.permissions.remove({ origins: [pattern] });
  }
  return false;
}
