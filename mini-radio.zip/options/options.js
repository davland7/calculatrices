import { ACTIONS, VALIDATE_STATES } from '../constants/constant.js';
import { sendMessage, getVersion } from '../utils/extension.js';
import { t } from '../utils/i18n.js';
import { fileToBase64 } from '../utils/image.js';

// Elements - Groupés par fonctionnalité
const elements = {
  close: document.getElementById("close"),
  version: document.getElementById("version"),
  shortcut: document.getElementById("playPauseShortcutElement"),
  volume: document.querySelectorAll("input[name=volume]:not(#resetVolume)"),

  // Form
  form: document.getElementById("customForm"),
  id: document.getElementById("id"),
  name: document.getElementById("name"),
  description: document.getElementById("description"),
  src: document.getElementById("src"),
  hls: document.getElementById("hls"),
  file: document.getElementById("file"),
  state: document.getElementById("state"),
  image: document.getElementById("image"),
  save: document.getElementById("save"),
  play: document.getElementById("play"),
  message: document.getElementById("message"),

  // Reset
  checkboxes: document.querySelectorAll('#resetOptions input[type="checkbox"]'),
  reset: document.getElementById("resetBtn")
};

// State
let itemsToReset = [];

// Utilities

function setVolume(volume) {
  const input = document.querySelector(`input[name="volume"][value="${volume}"]`);
  if (input) input.checked = true;
}

function getStationFromForm() {
  return {
    id: elements.id.value,
    name: elements.name.value.trim(),
    description: elements.description.value.trim(),
    src: elements.src.value.trim(),
    hls: !elements.hls.hidden,
    image: elements.image.src,
    state: elements.state.value || VALIDATE_STATES.PENDING
  };
}

function setCustomStation(station) {
  const { id, name, description, src, hls, image, state } = station;

  elements.id.value = id;
  elements.name.value = name;
  elements.description.value = description;
  elements.src.value = src;
  elements.state.value = state || VALIDATE_STATES.PENDING;
  elements.image.src = image;
  elements.hls.hidden = !hls;

  updateFormButtons(state);
  updateUI(t('options_custom_station_state_' + state), state);
}

function updateFormButtons(state) {
  const isFormValid = elements.form.checkValidity();
  const canSave = isFormValid && state !== VALIDATE_STATES.VALID && state !== VALIDATE_STATES.VALIDATING;
  const canPlay = isFormValid && (state === VALIDATE_STATES.VALID || state === VALIDATE_STATES.FALLBACK);

  elements.save.disabled = !canSave;
  elements.play.disabled = !canPlay;
}

function updateUI(text, validateClass = VALIDATE_STATES.PENDING) {
  elements.message.innerText = text;
  elements.message.className = validateClass;
}

// Event Listeners
elements.close.addEventListener('click', () => window.close());

// Volume
elements.volume.forEach(input => {
  input.title = `${100 * Number(input.value)}%`;
  input.addEventListener('change', async (e) => {
    await sendMessage(ACTIONS.OPTIONS_SET_VOLUME, { volume: Number(e.target.value) });
  });
});

// File upload
elements.file.addEventListener('change', async () => {
  if (elements.file.files.length > 0) {
    elements.image.src = await fileToBase64(elements.file.files[0]);
  }
});

// Form
elements.form.addEventListener("input", () => updateFormButtons(VALIDATE_STATES.PENDING));
elements.form.addEventListener("submit", async (e) => {
  e.preventDefault();

  try {
    updateUI(t('options_custom_station_state_validating'), VALIDATE_STATES.VALIDATING);

    const { station: saved } = await sendMessage(ACTIONS.OPTIONS_SET_CUSTOM_STATION, { station: getStationFromForm() });

    elements.hls.hidden = !saved.hls;
    elements.state.value = saved.state;

    updateFormButtons(saved.state);
    updateUI(t('options_custom_station_state_' + saved.state), saved.state);
  } catch (error) {
    console.error('[Options] Save failed:', error);
    updateUI(t('options_custom_station_state_fallback'), VALIDATE_STATES.FALLBACK);
    elements.play.disabled = true;
  }
});

// Play button
elements.play.addEventListener('click', () => {
  sendMessage(ACTIONS.OPTIONS_PLAY_STREAM, { station: getStationFromForm() });
});

// Reset
elements.checkboxes.forEach(checkbox => {
  checkbox.addEventListener("change", () => {
    itemsToReset = Array.from(elements.checkboxes).filter(c => c.checked).map(c => c.name);
    elements.reset.disabled = itemsToReset.length === 0;
  });
});

elements.reset.addEventListener('click', async () => {
  const itemsList = itemsToReset.map(item => '– ' + t('options_reset_label_' + item)).join('\n');

  if (!confirm(t('options_reset_confirm', [itemsList]))) return;

  try {
    elements.reset.disabled = true;
    elements.checkboxes.forEach(cb => cb.checked = false);

    const { results } = await sendMessage(ACTIONS.OPTIONS_RESET_ITEMS, { items: itemsToReset });

    if (results.volume !== undefined) setVolume(results.volume);
    if (results.custom_station !== undefined) setCustomStation(results.custom_station);
  } catch (error) {
    console.error('[Options] Reset failed:', error);
    itemsToReset.forEach(item => {
      const cb = document.querySelector(`input[name="${item}"]`);
      if (cb) cb.checked = true;
    });
  } finally {
    itemsToReset = [];
    elements.reset.disabled = true;
  }
});

// Initialization
(async () => {
  try {
    // i18n
    document.querySelectorAll('[data-i18n]').forEach(el => {
      el.textContent = t(el.dataset.i18n);
    });

    elements.version.textContent = getVersion();
    elements.name.placeholder = t('options_custom_station_placeholder_name');
    elements.src.placeholder = t('options_custom_station_placeholder_src');

    // Load data
    const { station, volume } = await sendMessage(ACTIONS.OPTIONS_GET_DATA);
    setVolume(volume);
    setCustomStation(station);

    // Shortcut
    chrome.commands.getAll((commands) => {
      const cmd = commands.find(c => c.name === 'playpause');
      if (cmd) elements.shortcut.textContent = `(${cmd.shortcut})`;
    });
  } catch (error) {
    console.error('[Options] Init failed:', error);
  }
})();
