import { ACTIONS, STATES } from '../constants/constant.js';
import { withErrorHandling } from '../utils/extension.js';
import { toDataURL } from '../utils/image.js';
import Hls from './hls.light.min.js';

/** @type {HTMLAudioElement} */
const audio = new Audio();
audio.volume = 0;
audio.preload = 'auto';
audio.crossOrigin = 'anonymous';

/** @type {Hls|null} */
let hlsInstance = null;
let currentState = STATES.STOPPED;
let isResetting = false;

function sendState(state) {
  currentState = state;

  chrome.runtime.sendMessage({
    action: ACTIONS.OFFSCREEN_STATE_CHANGED,
    state
  }, () => {
    const _ignore = chrome.runtime.lastError;
  });
}

function setVolume(volume) {
  audio.volume = volume;
}

async function resolveArtwork(image) {
  if (image.startsWith('data:image/')) {
    return image;
  }
  return await toDataURL(image);
}

// Playback functions
async function togglePlay() {
  try {
    if (audio.paused) {
      await audio.play();
    } else {
      audio.pause();
    }
  } catch (error) {
    console.error('[Offscreen] Toggle play failed:', error);
    sendState(STATES.ERROR);
  }
}

async function play(station, volume) {
  const { name, description, image, hls, src } = station;

  if (hlsInstance) {
    hlsInstance.destroy();
    hlsInstance = null;
  }

  isResetting = true;
  audio.pause();
  audio.src = '';
  audio.load();
  isResetting = false;

  setVolume(volume);

  const canPlayPromise = new Promise((resolve, reject) => {
    audio.addEventListener('canplay', resolve, { once: true });
    audio.addEventListener('error', reject, { once: true });
  });

  if (hls && Hls.isSupported()) {
    hlsInstance = new Hls();
    hlsInstance.attachMedia(audio);
    hlsInstance.on(Hls.Events.MEDIA_ATTACHED, () => {
      hlsInstance.loadSource(src);
    });
    hlsInstance.on(Hls.Events.ERROR, () => {
      hlsInstance.destroy();
      hlsInstance = null;
      sendState(STATES.ERROR);
    });
  } else {
    audio.src = src;
    audio.load();
  }

  if ('mediaSession' in navigator) {
    try {
      const artworkSrc = await resolveArtwork(image);
      navigator.mediaSession.metadata = new MediaMetadata({
        title: name,
        artist: description,
        artwork: [{ src: artworkSrc, sizes: '192x192', type: 'image/webp' }]
      });

      navigator.mediaSession.setActionHandler('play', async () => {
        try {
          if (audio.paused) await audio.play();
        } catch (error) {
          console.error('[Offscreen] MediaSession play failed:', error);
          sendState(STATES.ERROR);
        }
      });

      navigator.mediaSession.setActionHandler('pause', () => {
        if (!audio.paused) audio.pause();
      });

    } catch (error) {
      console.error('[Offscreen] MediaSession setup failed:', error);
    }
  }

  try {
    await canPlayPromise;
    await audio.play();
  } catch (error) {
    console.error('[Offscreen] Play failed:', error);
    sendState(STATES.ERROR);
  }
}

// Audio event listeners
audio.addEventListener('loadstart', () => {
  if (isResetting) return;
  sendState(STATES.LOADING);
});
audio.addEventListener('waiting', () => {
  if (isResetting) return;
  sendState(STATES.LOADING);
});
audio.addEventListener('playing', () => sendState(STATES.PLAYING));
audio.addEventListener('pause', () => {
  if (isResetting) return;
  sendState(STATES.PAUSED);
});
audio.addEventListener('ended', () => sendState(STATES.PAUSED));
audio.addEventListener('error', () => {
  // HLS errors are handled by HLS.Events.ERROR
  if (hlsInstance || isResetting) return;
  sendState(STATES.ERROR);
});

// Message handlers
const actions = {
  [ACTIONS.OFFSCREEN_PLAY]: withErrorHandling(async ({ request, sendResponse }) => {
    const { station, volume } = request;
    await play(station, volume);
    sendResponse({ success: true });
  }),

  [ACTIONS.OFFSCREEN_TOGGLE]: withErrorHandling(async ({ sendResponse }) => {
    await togglePlay();
    sendResponse({ success: true });
  }),

  [ACTIONS.OFFSCREEN_SET_VOLUME]: withErrorHandling(async ({ request, sendResponse }) => {
    const { volume } = request;

    setVolume(volume);
    sendResponse({ success: true });
  }),

  [ACTIONS.OFFSCREEN_GET_STATE]: withErrorHandling(async ({ sendResponse }) => {
    sendResponse({ success: true, state: currentState });
  })
};

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const handler = actions[request.action];
  if (handler) {
    handler({ request, sender, sendResponse });
    return true;
  }
  return false;
});
