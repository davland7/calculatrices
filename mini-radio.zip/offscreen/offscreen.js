import { ACTIONS, AUDIO_STATES } from '../constants/constant.js';
import { withErrorHandling } from '../utils/extension.js';
import { toDataURL } from '../utils/image.js';
import Hls from './hls.esm.js';

/** @type {HTMLAudioElement} */
const audio = new Audio();
audio.volume = 0;
audio.preload = 'auto';
audio.crossOrigin = 'anonymous';

/** @type {Hls|null} */
let hlsInstance = null;
let currentState = AUDIO_STATES.STOPPED;
let isResetting = false;

function sendState(state) {
  currentState = state;
  chrome.runtime.sendMessage({
    action: ACTIONS.OFFSCREEN_STATE_CHANGED,
    state
  }, () => {
    const _ignore = chrome.runtime.lastError;
  });
}

function setVolume(volume) {
  audio.volume = volume;
}

async function resolveArtwork(image) {
  return image.startsWith('data:image/') ? image : await toDataURL(image);
}

function resetAudio() {
  isResetting = true;
  audio.pause();
  audio.src = '';
  audio.load();

  if (hlsInstance) {
    hlsInstance.destroy();
    hlsInstance = null;
  }
  isResetting = false;
}

function setupHlsStream(src, cleanup, reject) {
  hlsInstance = new Hls({
    enableWorker: true,
    lowLatencyMode: true,
    liveSyncDurationCount: 3,
    liveMaxLatencyDurationCount: 10
  });

  hlsInstance.attachMedia(audio);

  hlsInstance.on(Hls.Events.MEDIA_ATTACHED, () => {
    hlsInstance.loadSource(src);
  });

  hlsInstance.on(Hls.Events.ERROR, (_event, data) => {
    if (!data.fatal) return;
    cleanup();
    sendState(AUDIO_STATES.ERROR);
    reject(new Error('HLS stream unavailable'));
  });
}

function setupDirectStream(src) {
  audio.src = src;
  audio.load();
}

function waitForCanPlay(src, isHls) {
  return new Promise((resolve, reject) => {
    let timeout;

    const cleanup = () => {
      clearTimeout(timeout);
      audio.removeEventListener('canplay', onCanPlay);
      audio.removeEventListener('error', onError);
    };

    const onCanPlay = () => { cleanup(); resolve(); };
    const onError = () => {
      cleanup();
      reject(new Error('Audio source unavailable'));
    };

    timeout = setTimeout(() => {
      cleanup();
      reject(new Error('Timeout loading audio (5s)'));
    }, 5000);

    audio.addEventListener('canplay', onCanPlay);
    audio.addEventListener('error', onError);

    if (isHls && Hls.isSupported()) {
      setupHlsStream(src, cleanup, reject);
    } else {
      setupDirectStream(src);
    }
  });
}

async function setupMediaSession(name, description, image) {
  if ('mediaSession' in navigator) {
    const artworkSrc = await resolveArtwork(image);
    navigator.mediaSession.metadata = new MediaMetadata({
      title: name,
      artist: description,
      artwork: [{ src: artworkSrc, sizes: '192x192', type: 'image/webp' }]
    });

    navigator.mediaSession.setActionHandler('play', async () => {
      try { if (audio.paused) await audio.play(); } catch (_) {
        sendState(AUDIO_STATES.ERROR);
      }
    });

    navigator.mediaSession.setActionHandler('pause', () => {
      if (!audio.paused) audio.pause();
    });
  }
}

async function playStation(station, volume) {
  const { name, description, image, hls, src } = station;

  resetAudio();
  setVolume(volume);

  try {
    const canPlayPromise = waitForCanPlay(src, hls);
    await setupMediaSession(name, description, image);
    await canPlayPromise;
    await audio.play();
  } catch (error) {
    console.warn('[Offscreen] Play failed:', error.message);
    sendState(AUDIO_STATES.ERROR);
  }
}

// Audio event listeners
audio.addEventListener('loadstart', () => !isResetting && sendState(AUDIO_STATES.LOADING));
audio.addEventListener('waiting', () => !isResetting && sendState(AUDIO_STATES.LOADING));
audio.addEventListener('playing', () => sendState(AUDIO_STATES.PLAYING));
audio.addEventListener('pause', () => !isResetting && sendState(AUDIO_STATES.PAUSED));
audio.addEventListener('ended', () => sendState(AUDIO_STATES.PAUSED));
audio.addEventListener('error', () => {
  if (!hlsInstance && !isResetting) {
    sendState(AUDIO_STATES.ERROR);
  }
});

// Message handlers
const actions = {
  [ACTIONS.OFFSCREEN_PLAY]: withErrorHandling(async ({ request }) => {
    if (request.station) {
      await playStation(request.station, request.volume);
    } else if (currentState === AUDIO_STATES.PLAYING || currentState === AUDIO_STATES.PAUSED) {
      if (audio.paused) {
        try { await audio.play(); } catch (_) {
          sendState(AUDIO_STATES.ERROR);
        }
      } else {
        audio.pause();
      }
    }
    return { success: true };
  }),
  [ACTIONS.OFFSCREEN_SET_VOLUME]: withErrorHandling(async ({ request }) => {
    setVolume(request.volume);
    return { success: true };
  }),
  [ACTIONS.OFFSCREEN_GET_STATE]: withErrorHandling(async () => {
    return { success: true, state: currentState };
  })
};

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const handler = actions[request.action];
  if (handler) {
    return handler({ request, sender, sendResponse });
  }
  return false;
});
