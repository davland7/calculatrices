import { API_ENDPOINTS } from "../constants/constant.js";
import { getLangCode } from "../utils/i18n.js";
import { initData, migrateToV3 } from "./utils/storage.js";

export async function handleInstalled(details) {
  const isInstall = details.reason === "install";
  const isUpdateFromV2 =
    details.reason === "update" && details.previousVersion?.startsWith("2.");

  if (isInstall || isUpdateFromV2) {
    await initData();

    if (isInstall) {
      chrome.tabs.create({
        url: chrome.runtime.getURL(`welcome.html#${getLangCode()}Install`)
      });
      await fetch(`${API_ENDPOINTS.BASE_URL}${API_ENDPOINTS.LEAD_PATH}`);
    }

    if (isUpdateFromV2) {
      chrome.tabs.create({
        url: chrome.runtime.getURL(`welcome.html#${getLangCode()}Update`)
      });
      await migrateToV3();
    }
  }
}
