import { toDataURL } from '../../utils/image.js';
import { VALIDATE_STATES } from '../../constants/constant.js';

/* Default Data */
const defaultData = {
  history: ["919MHzQUE", "919MHzMTL", "933MHzQUE", "943MHzMTL", "951MHzMTL", "969MHzMTL", "981MHzQUE", "985MHzMTL", "995MHzMTL", "1021MHzQUE", "1057MHzMTL", "1073MHzMTL"],
  volume: 0.2,
  customStation: {
    id: "customStation",
    name: "",
    description: "",
    src: "",
    hls: false,
    image: "/assets/images/stations/default.webp",
    state: VALIDATE_STATES.PENDING
  }
};

/* History Handling */
export async function setHistory(history) {
  return await chrome.storage.sync.set({ history });
}

export async function getHistory() {
  const { history } = await chrome.storage.sync.get({ history: defaultData.history });
  return history;
}

export async function resetHistory() {
  const customStation = await getCustomStation();

  // Keep custom station in history if it has a valid URL
  if (customStation.state === VALIDATE_STATES.VALID || customStation.state === VALIDATE_STATES.FALLBACK) {
    return await setHistory([...defaultData.history, "customStation"]);
  }

  return await setHistory(defaultData.history);
}

/* Volume Handling */
export async function setVolume(volume) {
  return await chrome.storage.local.set({ volume });
}

export async function getVolume() {
  const { volume } = await chrome.storage.local.get({ volume: defaultData.volume });
  return Number(volume);
}

export async function resetVolume() {
  await setVolume(defaultData.volume);
  return defaultData.volume;
}

/* Custom Station Image Handling */
export async function getCustomStationImage() {
  const { customStationImage } = await chrome.storage.local.get("customStationImage");
  return customStationImage || defaultData.customStation.image;
}

export async function setCustomStationImage(urlOrBase64) {
  let base64Image = urlOrBase64;

  // Convert to base64 if it's a URL
  if (!urlOrBase64.startsWith("data:image/")) {
    base64Image = await toDataURL(urlOrBase64);
  }

  await chrome.storage.local.set({ customStationImage: base64Image });
  return base64Image;
}

export async function clearCustomStationImage() {
  await chrome.storage.local.remove("customStationImage");
}

/* Custom Station Handling (Fixed) */

/**
 * Saves the custom station.
 * - If the image is Base64 ('data:image/...'), it is stored in 'local'.
 * - If the image is a URL ('http://' or '/assets/'), it is stored in 'sync'
 * and any previous 'local' image is cleared.
 */
export async function setCustomStation(station) {
  const isDataImage = station.image?.startsWith("data:image/");

  let localImagePromise;
  let stationToSync;

  if (isDataImage) {
    localImagePromise = setCustomStationImage(station.image);
    stationToSync = { ...station, image: defaultData.customStation.image };
  } else {
    localImagePromise = clearCustomStationImage();
    stationToSync = {
      ...station,
      image: station.image || defaultData.customStation.image
    };
  }

  const syncPromise = chrome.storage.sync.set({ station: stationToSync });
  await Promise.all([syncPromise, localImagePromise]);
  return stationToSync;
}

/**
 * Retrieves the custom station by merging 'sync' and 'local'.
 * The 'local' image (Base64) takes priority over the 'sync' image (URL).
 */
export async function getCustomStation() {
  const [{ station }, { customStationImage }] = await Promise.all([
    chrome.storage.sync.get({ station: defaultData.customStation }),
    chrome.storage.local.get("customStationImage")
  ]);
  const finalImage = customStationImage || station.image;

  // Merge with defaults to ensure all properties (like hls) are present
  return { ...defaultData.customStation, ...station, image: finalImage };
}

export async function resetCustomStation() {
  await clearCustomStationImage();
  const history = await getHistory();
  await setHistory(history.filter(id => id !== "customStation"));
  await chrome.storage.sync.set({ station: defaultData.customStation });
  return defaultData.customStation;
}

/* Stations Handling */
export async function getStations() {
  try {
    // Load default stations
    const url = chrome.runtime.getURL("assets/data/stations.json");
    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP error ${response.status}`);
    let stations = await response.json();

    // Add the custom station
    const customStation = await getCustomStation();
    stations.unshift(customStation);

    // Reorder according to history
    const history = await getHistory();
    if (Array.isArray(history) && history.length > 0) {
      stations = history
        .map(id => stations.find(s => s.id === id))
        .filter(Boolean);
    }

    return stations;
  } catch (error) {
    console.error("[Data] Critical: Failed to load or reorder stations:", error);
    return [];
  }
}

/* Current Station Handling */
export async function getCurrentStation() {
  const stations = await getStations();
  return stations[0];
}

/* History Manipulation */
export async function moveToTopOfHistory(stationId) {
  let history = await getHistory();
  history = history.filter(id => id !== stationId);
  history.unshift(stationId);
  await setHistory(history);

  return history;
}

/* Custom Station in History Handling */
export async function setCustomStationInHistory() {
  const history = await getHistory();

  // Only add custom station if not already in history
  if (!history.includes("customStation")) {
    const updated = [...history, "customStation"];
    await setHistory(updated);
    return updated;
  }

  return history;
}

/* Initial Data Setup */
export async function initData() {
  await resetCustomStation();
  await Promise.all([
    resetHistory(),
    resetVolume()
  ]);
}

export async function migrateToV3() {
  // Clean up V2 data (remove() is safe even if keys don't exist)
  await chrome.storage.local.remove(['active', 'more', 'windowId']);
}
