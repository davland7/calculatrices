import { API_ENDPOINTS, VALIDATE_STATES } from '../../constants/constant.js';

export function buildProxyUrl(url, id) {
  const params = new URLSearchParams({ url, id });

  return `${API_ENDPOINTS.BASE_URL}${API_ENDPOINTS.PROXY_PATH}?${params.toString()}`;
}

export async function trackStation(id) {
  try {
    const body = { stationId: id };

    const response = await fetch(`${API_ENDPOINTS.BASE_URL}${API_ENDPOINTS.TRACK_PATH}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(4000)
    });

    if (!response.ok) {
      return null;
    }

    return await response.json();
  } catch (error) {
    console.error('[Network] Track station failed', error);
    return null;
  }
}

export async function validateStream(url) {
  try {
    const params = new URLSearchParams({ url });

    const response = await fetch(
      `${API_ENDPOINTS.BASE_URL}${API_ENDPOINTS.VALIDATE_PATH}?${params.toString()}`,
      { signal: AbortSignal.timeout(5000) }
    );

    return await response.json();
  } catch (error) {
    const isTimeout = error.name === 'AbortError';

    return {
      state: VALIDATE_STATES.FALLBACK,
      hls: false,
      errorCode: isTimeout ? 'timeout' : 'network_error'
    };
  }
}
