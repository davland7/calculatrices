import { AUDIO_STATES } from "../../constants/constant.js";
import { t } from "../../utils/i18n.js";

const BADGE_STATES = Object.freeze({
  IDLE: { text: "", color: "#000000", title: t("name") },
  ON: { text: "ON", color: "#28a745", title: t("status_playing") },
  LOADING: { text: "ON", color: "#ffc107", title: t("status_loading") },
  ERROR: {
    text: "ON",
    color: "#dc3545",
    title: t("status_error")
  }
});

const AUDIO_TO_BADGE_MAP = Object.freeze({
  playing: "ON",
  loading: "LOADING",
  paused: "IDLE",
  error: "ERROR",
  stopped: "IDLE"
});

/**
 * Update the extension badge based on audio state
 * @param {string} audioState - One of "playing", "loading", "paused", "error", "stopped"
 */
export async function updateBadge(audioState = AUDIO_STATES.STOPPED) {
  const badgeKey = AUDIO_TO_BADGE_MAP[audioState] || "stopped";
  const { text, color, title } = BADGE_STATES[badgeKey] || BADGE_STATES.IDLE;

  try {
    await Promise.all([
      chrome.action.setBadgeText({ text }),
      chrome.action.setBadgeBackgroundColor({ color }),
      chrome.action.setTitle({ title })
    ]);
  } catch (error) {
    console.warn("[Badge Update] Failed to update badge:", error);
  }
}
