import { ACTIONS } from "../../constants/constant.js";
import { sendMessage } from "../../utils/extension.js";
import { buildProxyUrl, trackStation } from "./network.js";
import { createOffscreenDocument, hasOffscreenDocument } from "./offscreen.js";
import { getVolume, moveToTopOfHistory } from "./storage.js";

let playLock = Promise.resolve();

export async function playStation(station) {
  playLock = playLock.catch(() => {}).then(() => playStationInternal(station));
  return playLock;
}

async function playStationInternal(station) {
  const { id, hls, src } = station;
  const volume = await getVolume();

  if (!(await hasOffscreenDocument())) {
    await createOffscreenDocument();
  }

  let stationToPlay = { ...station };

  if (id !== "customStation") {
    if (hls) {
      trackStation(id);
    } else {
      stationToPlay.src = buildProxyUrl(src, id);
    }
  }

  await sendMessage(ACTIONS.OFFSCREEN_PLAY, { station: stationToPlay, volume });
  await moveToTopOfHistory(id);
}
