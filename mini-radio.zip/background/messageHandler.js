import { closeOffscreenDocument, createOffscreenDocument, hasOffscreenDocument } from './utils/offscreen.js';
import { sendMessage, withErrorHandling } from '../utils/extension.js';
import { ACTIONS, STATES, VALIDATE_STATES } from '../constants/constant.js';
import { updateBadge } from './utils/badge.js';
import { trackStation, buildProxyUrl, validateStream } from './utils/network.js';
import {
  moveToTopOfHistory,
  resetCustomStation,
  resetHistory,
  resetVolume,
  getCurrentStation,
  getCustomStation,
  getVolume,
  getStations,
  setCustomStation,
  setVolume,
  setCustomStationInHistory
} from './utils/storage.js';

let playLock = Promise.resolve();

function playStation(station) {
  playLock = playLock
    .catch(() => {})
    .then(() => playStationInternal(station));
  return playLock;
}

async function playStationInternal(station) {
  const { id, hls, src } = station;
  const volume = await getVolume();

  if (!await hasOffscreenDocument()) {
    await createOffscreenDocument();
  }

  let stationToPlay = { ...station };

  if (id !== "customStation") {
    if (hls) {
      trackStation(id);
    } else {
      stationToPlay.src = buildProxyUrl(src, id);
    }
  }

  await sendMessage(ACTIONS.OFFSCREEN_PLAY, { station: stationToPlay, volume });
  await moveToTopOfHistory(id);
}

export function handleMessage(request, sender, sendResponse) {
  const handler = actions[request.action];

  if (handler) {
    return handler({ request, sender, sendResponse });
  }

  return false;
}

export const actions = {
  [ACTIONS.POPUP_GET_DATA]: withErrorHandling(async ({ sendResponse }) => {
    const stations = await getStations();

    let state = STATES.STOPPED;
    if (await hasOffscreenDocument()) {
      const result = await sendMessage(ACTIONS.OFFSCREEN_GET_STATE) || {};
      state = result.state;

      // It not normal kill offscreen when loading, so consider it stopped
      if (state === STATES.ERROR || state === STATES.LOADING) {
        state = STATES.STOPPED;
        await closeOffscreenDocument();
      }
    } else {
      await updateBadge(STATES.STOPPED);
    }

    sendResponse({ success: true, state, stations });
  }),

  [ACTIONS.OPTIONS_GET_DATA]: withErrorHandling(async ({ sendResponse }) => {
    sendResponse({
      success: true,
      station: await getCustomStation(),
      volume: await getVolume()
    });
  }),

  [ACTIONS.POPUP_PLAY_STREAM]: withErrorHandling(async ({ request, sendResponse }) => {
    const { station } = request;
    await playStation(station);
    sendResponse({ success: true });
  }),

  [ACTIONS.OPTIONS_PLAY_STREAM]: withErrorHandling(async ({ sendResponse }) => {
    const station = await getCustomStation();
    await playStation(station);
    sendResponse({ success: true });
  }),

  [ACTIONS.OPTIONS_SET_CUSTOM_STATION]: withErrorHandling(async ({ request, sendResponse }) => {
    const { station } = request;
    const { src: currentSrc } = await getCustomStation();

    let stationToSave = { ...station };

    // Si l'URL change, on valide AVANT de sauvegarder
    if (stationToSave.src && stationToSave.src !== currentSrc) {
      const validate = await validateStream(stationToSave.src);

      stationToSave.state = validate.state || VALIDATE_STATES.FALLBACK;
      stationToSave.hls = validate.hls || false;

      // Si invalide, on refuse la sauvegarde
      if (validate.state === VALIDATE_STATES.INVALID) {
        console.log('[MessageHandler] Invalid stream - not saving');
        sendResponse({ success: true, station: stationToSave });
        return;
      }

      // URL valide, on peut fermer l'offscreen si nécessaire
      const current = await getCurrentStation();
      if (current.id === 0) await closeOffscreenDocument();
    }

    // Sauvegarde seulement si valide (ou si c'est juste un changement de nom/description)
    await setCustomStation(stationToSave);
    await setCustomStationInHistory();

    sendResponse({ success: true, station: stationToSave });
  }),

  [ACTIONS.OPTIONS_SET_VOLUME]: withErrorHandling(async ({ request, sendResponse }) => {
    const { volume } = request;

    await setVolume(volume);

    if (await hasOffscreenDocument()) {
      await sendMessage(ACTIONS.OFFSCREEN_SET_VOLUME, { volume });
    }

    sendResponse({ success: true });
  }),

  [ACTIONS.OPTIONS_RESET_ITEMS]: withErrorHandling(async ({ request, sendResponse }) => {
    const { items } = request;

    // Fermer l'offscreen AVANT de reset les données
    const shouldCloseOffscreen = items.includes("custom_station") || items.includes("history");
    if (shouldCloseOffscreen && await hasOffscreenDocument()) {
      await closeOffscreenDocument();
    }

    const results = {};
    const resetActions = {
      custom_station: resetCustomStation,
      history: resetHistory,
      volume: resetVolume,
    };

    for (const item of items) {
      const action = resetActions[item];
      if (action) {
        results[item] = await action();
      }
    }

    // Si on a reset le volume et que l'offscreen existe, mettre à jour le volume en temps réel
    if (items.includes("volume") && await hasOffscreenDocument()) {
      await sendMessage(ACTIONS.OFFSCREEN_SET_VOLUME, { volume: results.volume });
    }

    sendResponse({ success: true, results });
  }),

  [ACTIONS.OFFSCREEN_STATE_CHANGED]: withErrorHandling(async ({ request, sendResponse }) => {
    const { state } = request;
    await updateBadge(state);
    sendResponse({ success: true });
  })
};
