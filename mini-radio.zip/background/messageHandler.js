import {
  ACTIONS,
  AUDIO_STATES,
  VALIDATE_STATES
} from "../constants/constant.js";
import { sendMessage, withErrorHandling } from "../utils/extension.js";
import { updateBadge } from "./utils/badge.js";
import { validateStream } from "./utils/network.js";
import {
  closeOffscreenDocument,
  hasOffscreenDocument
} from "./utils/offscreen.js";
import { playStation } from "./utils/player.js";
import {
  getCustomStation,
  getStations,
  getVolume,
  isCustomStationCurrent,
  removeCustomStationFromHistory,
  resetCustomStation,
  resetHistory,
  resetVolume,
  setCustomStation,
  setVolume
} from "./utils/storage.js";

export function handleMessage(request, sender, sendResponse) {
  const handler = actions[request.action];

  if (handler) {
    return handler({ request, sender, sendResponse });
  }

  return false;
}

export const actions = {
  [ACTIONS.POPUP_GET_DATA]: withErrorHandling(async () => {
    const stations = await getStations();

    let state = AUDIO_STATES.STOPPED;
    if (await hasOffscreenDocument()) {
      try {
        const result = (await sendMessage(ACTIONS.OFFSCREEN_GET_STATE)) || {};
        state = result.state;
      } catch (error) {
        console.error("[MessageHandler] Error getting offscreen state:", error);
        await closeOffscreenDocument();
      }

      // It's not normal to have offscreen loading/error on popup open, consider it stopped
      if (state === AUDIO_STATES.ERROR || state === AUDIO_STATES.LOADING) {
        state = AUDIO_STATES.STOPPED;
        await closeOffscreenDocument();
      }
    } else {
      await updateBadge(AUDIO_STATES.STOPPED);
    }

    return { success: true, state, stations };
  }),

  [ACTIONS.POPUP_PLAY_STREAM]: withErrorHandling(async ({ request }) => {
    const { station } = request;
    await playStation(station);
    return { success: true };
  }),

  [ACTIONS.OPTIONS_GET_DATA]: withErrorHandling(async () => {
    return {
      success: true,
      station: await getCustomStation(),
      volume: await getVolume()
    };
  }),

  [ACTIONS.OPTIONS_PLAY_STREAM]: withErrorHandling(async () => {
    const station = await getCustomStation();
    await playStation(station);
    return { success: true };
  }),

  [ACTIONS.OPTIONS_SET_CUSTOM_STATION]: withErrorHandling(
    async ({ request }) => {
      const { station } = request;
      const { src: customSrc } = await getCustomStation();

      let stationToSave = { ...station };

      // If src changed: close offscreen, remove from history, validate new stream
      if (stationToSave.src && stationToSave.src !== customSrc) {
        if (
          (await isCustomStationCurrent()) &&
          (await hasOffscreenDocument())
        ) {
          await closeOffscreenDocument();
        }

        await removeCustomStationFromHistory();

        const validate = await validateStream(stationToSave.src);
        stationToSave.state = validate.state || VALIDATE_STATES.FALLBACK;
        stationToSave.hls = validate.hls || false;
      }

      await setCustomStation(stationToSave);

      return { success: true, station: stationToSave };
    }
  ),

  [ACTIONS.OPTIONS_SET_VOLUME]: withErrorHandling(async ({ request }) => {
    const { volume } = request;

    await setVolume(volume);

    if (await hasOffscreenDocument()) {
      await sendMessage(ACTIONS.OFFSCREEN_SET_VOLUME, { volume });
    }

    return { success: true };
  }),

  [ACTIONS.OPTIONS_RESET_ITEMS]: withErrorHandling(async ({ request }) => {
    const { items } = request;

    const shouldCloseOffscreen =
      (items.includes("custom_station") && (await isCustomStationCurrent())) ||
      items.includes("history");
    if (shouldCloseOffscreen && (await hasOffscreenDocument())) {
      await closeOffscreenDocument();
    }

    const results = {};
    const resetActions = {
      custom_station: resetCustomStation,
      history: resetHistory,
      volume: resetVolume
    };

    for (const item of items) {
      const action = resetActions[item];
      if (action) {
        results[item] = await action();
      }
    }

    if (items.includes("volume") && (await hasOffscreenDocument())) {
      await sendMessage(ACTIONS.OFFSCREEN_SET_VOLUME, {
        volume: results.volume
      });
    }

    return { success: true, results };
  }),

  [ACTIONS.OFFSCREEN_STATE_CHANGED]: withErrorHandling(async ({ request }) => {
    const { state } = request;
    await updateBadge(state);
    return { success: true };
  })
};
