import { API_ENDPOINTS, REQUIRED_ORIGINS } from "../constants/constant.js";
import { resetCoreGranted } from "../utils/permissions.js";
import { closeOffscreenDocument } from "./utils/offscreen.js";

export async function handlePermissionsAdded(permissions) {
  const hasCore = REQUIRED_ORIGINS.every((origin) =>
    permissions.origins?.includes(origin),
  );

  if (hasCore) {
    try {
      const response = await fetch(
        `${API_ENDPOINTS.BASE_URL}${API_ENDPOINTS.LEAD_PATH}`,
        { method: "POST" },
      );
      if (!response.ok) {
        console.warn(
          "[PermissionsHandler] Lead request failed with status:",
          response.status,
        );
      }
    } catch (error) {
      console.warn("[PermissionsHandler] Lead request error:", error);
    }
  }
}

export function handlePermissionsRemoved(permissions) {
  resetCoreGranted();
  if (permissions.origins && permissions.origins.length > 0) {
    closeOffscreenDocument();
  }
}
