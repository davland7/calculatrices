import { ACTIONS } from "../constants/constant.js";
import { sendMessage } from "../utils/extension.js";
import { hasOffscreenDocument } from "./utils/offscreen.js";
import { playStation } from "./utils/player.js";
import { getCurrentStation } from "./utils/storage.js";

export async function handleCommand(command) {
  if (command === "playpause") {
    try {
      if (await hasOffscreenDocument()) {
        await sendMessage(ACTIONS.OFFSCREEN_PLAY);
      } else {
        const station = await getCurrentStation();
        await playStation(station);
      }
    } catch (error) {
      console.error(
        "[Command Handler] Failed to handle play/pause command:",
        error
      );
    }
  } else {
    console.warn(`[Command Handler] Unrecognized command: ${command}`);
  }
}
