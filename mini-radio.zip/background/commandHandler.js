import { getVolume, getCurrentStation } from './utils/storage.js';
import { createOffscreenDocument, hasOffscreenDocument } from './utils/offscreen.js';
import { sendMessage } from '../utils/extension.js';
import { ACTIONS } from '../constants/constant.js';

export async function handleCommand(command) {
  if (command === "playpause") {
    try {
      if (await hasOffscreenDocument()) {
        await sendMessage(ACTIONS.OFFSCREEN_PLAY);
      } else {
        await createOffscreenDocument();

        const station = await getCurrentStation();
        const volume = await getVolume();

        await sendMessage(ACTIONS.OFFSCREEN_PLAY, { station, volume });
      }
    } catch (error) {
      console.error("[Command Handler] Failed to handle play/pause command:", error);
    }
  } else {
    console.warn(`[Command Handler] Unrecognized command: ${command}`);
  }
};
