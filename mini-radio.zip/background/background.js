import { handleCommand } from "./commandHandler.js";
import { handleInstalled } from "./installedHandler.js";
import { handleMessage } from "./messageHandler.js";
import {
  handlePermissionsAdded,
  handlePermissionsRemoved,
} from "./permissionsHandler.js";

chrome.commands.onCommand.addListener(handleCommand);
chrome.runtime.onInstalled.addListener(handleInstalled);
chrome.runtime.onMessage.addListener(handleMessage);
chrome.permissions.onAdded.addListener(handlePermissionsAdded);
chrome.permissions.onRemoved.addListener(handlePermissionsRemoved);
