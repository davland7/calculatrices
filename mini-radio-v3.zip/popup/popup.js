import { t } from "../utils/i18n.js";
import { sendMessage } from "../utils/extension.js";
import { ACTIONS, STATES } from "../constants/constant.js";

const elements = {
  stations: document.getElementById('stations'),
  template: document.querySelector('template'),
  pagination: document.querySelector('nav ul'),
  options: document.getElementById("optionsPage")
};

// Player button states configuration
const playerStateConfig = {
  [STATES.LOADING]: { className: 'station__control--loading', titleKey: 'popup_tooltip_loading' },
  [STATES.PLAYING]: { className: 'station__control--pause', titleKey: 'popup_tooltip_pause' },
  [STATES.PAUSED]: { className: 'station__control--play', titleKey: 'popup_tooltip_play' },
  [STATES.ERROR]: { className: 'station__control--play', titleKey: 'popup_tooltip_play' }
};

const ITEMS_PER_PAGE = 4;
let currentState = STATES.STOPPED;
let currentPage = 1;

// Player button state management
function updatePlayerButtonState(newState) {
  currentState = newState;
  const buttons = document.querySelectorAll('.station__control');
  const allClasses = Object.values(playerStateConfig).map(c => c.className);
  const config = playerStateConfig[newState] || playerStateConfig[STATES.PAUSED];

  buttons.forEach((btn, i) => {
    btn.classList.remove(...allClasses);
    const targetConfig = i === 0 ? config : playerStateConfig[STATES.PAUSED];
    btn.classList.add(targetConfig.className);
    btn.title = t(targetConfig.titleKey);
  });
}

// Pagination
function displayPage(page) {
  currentPage = page;

  elements.pagination.querySelectorAll('button').forEach(btn => {
    btn.classList.toggle('active', Number(btn.dataset.page) === page);
  });

  const items = Array.from(elements.stations.children).slice(1);
  const start = (page - 1) * ITEMS_PER_PAGE;
  const end = start + ITEMS_PER_PAGE;

  items.forEach((item, i) => {
    item.style.display = (i >= start && i < end) ? 'grid' : 'none';
  });
}

// Station handling
async function playStation(event, station) {
  const clickedItem = event.currentTarget.closest('.station');
  const isFirst = elements.stations.firstElementChild === clickedItem;

  if (isFirst) {
    const action = (currentState === STATES.STOPPED || currentState === STATES.ERROR)
      ? ACTIONS.POPUP_PLAY_STREAM
      : ACTIONS.OFFSCREEN_TOGGLE;

    await sendMessage(action, action === ACTIONS.POPUP_PLAY_STREAM ? { station } : undefined);
    return;
  }

  elements.stations.prepend(clickedItem);
  elements.stations.classList.add('stations--locked');
  displayPage(currentPage);

  await sendMessage(ACTIONS.POPUP_PLAY_STREAM, { station });
}

function renderStation(station) {
  const { image, name, description } = station;
  const clone = elements.template.content.cloneNode(true);

  clone.querySelector('.station__image').src = image;
  clone.querySelector('.station__name').textContent = name;
  clone.querySelector('.station__description').textContent = description;

  const btn = clone.querySelector('.station__control');
  btn.addEventListener('click', (e) => playStation(e, station));
  btn.title = t(playerStateConfig[STATES.PAUSED].titleKey);

  return clone;
}

function addCustomStationButton() {
  const li = document.createElement('li');
  li.classList.add('station--custom');

  const btn = document.createElement('button');
  btn.textContent = t('popup_add_custom_station');
  btn.addEventListener('click', () => chrome.runtime.openOptionsPage());

  li.appendChild(btn);
  elements.stations.appendChild(li);
}

// Message handler
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === ACTIONS.OFFSCREEN_STATE_CHANGED) {
    updatePlayerButtonState(message.state);
    elements.stations.classList.remove('stations--locked');
  }
  return false;
});

// Initialization
(async () => {
  try {
    const { state, stations } = await sendMessage(ACTIONS.POPUP_GET_DATA);

    stations.forEach(station => {
      elements.stations.appendChild(renderStation(station));
    });

    updatePlayerButtonState(state);

    if (stations.length < 13) addCustomStationButton();

    // Options link
    elements.options.textContent = t('popup_options_page');
    elements.options.addEventListener('click', (e) => {
      e.preventDefault();
      chrome.runtime.openOptionsPage();
    });

    // Pagination
    elements.pagination.addEventListener('click', (e) => {
      if (e.target.tagName === 'BUTTON') {
        displayPage(Number(e.target.dataset.page));
      }
    });

    displayPage(1);
  } catch (error) {
    console.error('[Popup] Init failed:', error);
  }
})();
